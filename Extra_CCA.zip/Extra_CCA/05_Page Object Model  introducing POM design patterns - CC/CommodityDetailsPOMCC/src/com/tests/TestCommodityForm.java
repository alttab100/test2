package com.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestCommodityForm {

	private CommodityForm commodityForm;
	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeMethod
	public void launchDriver() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);
	}

	@Test
	public void test_Commodity_Details() {

		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CommodityDetails/");
		commodityForm = new CommodityForm(driver);
		commodityForm.setName("LG 335 Refrigerator");
		commodityForm.setWeight("100");
		commodityForm.setLength("450");
		commodityForm.setWidth("520");
		commodityForm.setHeight("1200");
		commodityForm.clickAdd();

		try {
			assertEquals("1", commodityForm.getCount());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			assertEquals("100", commodityForm.getTotal());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		commodityForm.setName("Leather Sofa Set");
		commodityForm.setWeight("120");
		commodityForm.setLength("400");
		commodityForm.setWidth("800");
		commodityForm.setHeight("55");
		commodityForm.clickAdd();

		try {
			assertEquals("2", commodityForm.getCount());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			assertEquals("220", commodityForm.getTotal());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

	}

	@AfterMethod
	private void quitDriver() {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

}
