import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	private static WebElement result1;
	private static WebElement result2;
	private static WebElement result3;
	private static WebElement result4;
	private static WebElement result5;
	private static WebElement result6;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\312356\\Downloads\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/CompanyOffersDiscount/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testUntitled() throws Exception {
		driver.get(baseUrl + "/index.html");
		// fill your code
		driver.findElement(By.id("weight")).clear();
		driver.findElement(By.id("weight")).sendKeys("100");
		driver.findElement(By.id("distance")).clear();
		driver.findElement(By.id("distance")).sendKeys("200");
		driver.findElement(By.id("submit")).click();
		result1 = driver.findElement(By.id("result"));
		try {
			assertEquals("Datax shipping company offers discount", result1.getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		driver.findElement(By.id("weight")).clear();
		driver.findElement(By.id("weight")).sendKeys("80");
		driver.findElement(By.id("distance")).clear();
		driver.findElement(By.id("distance")).sendKeys("500");
		driver.findElement(By.id("submit")).click();
		result2 = driver.findElement(By.id("result"));
		try {
			assertEquals("Datax shipping company offers discount", result2.getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		driver.findElement(By.id("weight")).clear();
		driver.findElement(By.id("weight")).sendKeys("60");
		driver.findElement(By.id("distance")).clear();
		driver.findElement(By.id("distance")).sendKeys("110");
		driver.findElement(By.id("submit")).click();
		result3 = driver.findElement(By.id("result"));
		try {
			assertEquals("Datax shipping offers no discount", result3.getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		driver.findElement(By.id("weight")).clear();
		driver.findElement(By.id("weight")).sendKeys("120");
		driver.findElement(By.id("distance")).clear();
		driver.findElement(By.id("distance")).sendKeys("520");
		driver.findElement(By.id("submit")).click();
		result4 = driver.findElement(By.id("result"));
		try {
			assertEquals("Datax shipping company offers discount", result4.getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		driver.findElement(By.id("weight")).clear();
		driver.findElement(By.id("weight")).sendKeys("300");
		driver.findElement(By.id("distance")).clear();
		driver.findElement(By.id("distance")).sendKeys("200");
		driver.findElement(By.id("submit")).click();
		result5 = driver.findElement(By.id("result"));
		try {
			assertEquals("Datax shipping company offers discount", result5.getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		driver.findElement(By.id("weight")).clear();
		driver.findElement(By.id("weight")).sendKeys("50");
		driver.findElement(By.id("distance")).clear();
		driver.findElement(By.id("distance")).sendKeys("150");
		driver.findElement(By.id("submit")).click();
		result6 = driver.findElement(By.id("result"));
		try {
			assertEquals("Datax shipping offers no discount", result6.getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
