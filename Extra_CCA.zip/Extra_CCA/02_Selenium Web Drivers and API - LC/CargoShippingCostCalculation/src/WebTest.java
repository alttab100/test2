import java.util.regex.Pattern;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;

public class WebTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;

	private StringBuffer verificationErrors = new StringBuffer();
	static String url;
	static WebElement weight, air, road, ship, premium, calculate, result;
	static String result1,result2,result3;

	@Before
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/CostCalculation/";
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}

	@Test
	public void testWeb() throws Exception {
		driver.get(baseUrl);
		// fill your code
		driver.findElement(By.id("weight")).clear();
		driver.findElement(By.id("weight")).sendKeys("100");
		driver.findElement(By.id("air")).click();
		driver.findElement(By.id("calculate")).click();
		try {
			result1 = "result";
			assertEquals("Dear Customer, your total shipping cost is $100",
					driver.findElement(By.id(result1)).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("ship")).click();
		driver.findElement(By.id("calculate")).click();
		try {
			result2 = "result";
			assertEquals("Dear Customer, your total shipping cost is $70",
					driver.findElement(By.id(result2)).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("road")).click();
		driver.findElement(By.id("calculate")).click();
		try {
			result3 = "result";
			assertEquals("Dear Customer, your total shipping cost is $50",
					driver.findElement(By.id(result3)).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@After
	public void tearDown() throws Exception {

		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
