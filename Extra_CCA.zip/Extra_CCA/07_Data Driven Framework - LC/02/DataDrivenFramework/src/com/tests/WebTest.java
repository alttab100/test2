package com.tests;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFCell;

import org.apache.poi.xssf.usermodel.XSSFRow;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class WebTest {
	private static WebDriver driver;

	@BeforeMethod
	public void driverSetUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\Development_Avecto\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CustomerRegistration/Index");
		// driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Test(dataProvider = "customerData")
	public void testCustomer(String name, String age, String address, String phoneNumber, String email) {
		System.out.println(name + "\n" + age + "\n" + address + "\n" + phoneNumber + "\n" + email);
	}

	@DataProvider
	public Object[][] customerData() throws IOException {
		Object[][] arrayObject = getExcelData(
				"D:\\Development_Avecto\\Ebox_Workspace\\DataDrivenFramework\\CustomerDetails.xlsx", "Sheet1");
		return arrayObject;
	}

	public Object[][] getExcelData(String fileName, String sheetName) throws IOException {
		Object[][] arrayExcelData = null;
		FileInputStream fs = new FileInputStream(fileName);
		XSSFWorkbook wb = new XSSFWorkbook(fs);
		XSSFSheet sh = wb.getSheet(sheetName);
		int totalNoOfCols = 5;
		int totalNoOfRows = 1;
		System.out.println(totalNoOfCols+"\n"+totalNoOfRows);
		arrayExcelData = new String[totalNoOfRows][totalNoOfCols];
		for (int i = 1; i <= totalNoOfRows; i++) {
			for (int j = 1; j <totalNoOfCols; j++) {
				XSSFCell cell = sh.getRow(i).getCell(j);
				if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
					arrayExcelData[i - 1][j] = cell.getNumericCellValue();
				} else {
					arrayExcelData[i - 1][j] = cell.getStringCellValue();
				}
			}

		}
		return arrayExcelData;
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
}
