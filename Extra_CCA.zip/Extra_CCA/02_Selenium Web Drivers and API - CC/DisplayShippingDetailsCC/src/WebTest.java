import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class WebTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	static WebElement h2element, sourceId, destinationId, weightId, costId, dateId, deliveryId;
	static WebElement calculateId, resultId;

	public static String url;

	@Before
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/ShippingDetails/";
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}

	@Test
	public void testWeb() throws Exception {
		driver.get(baseUrl);
		// fill your code
		h2element = driver.findElement(By.tagName("h1"));
		sourceId = driver.findElement(By.id("source"));
		destinationId = driver.findElement(By.id("destination"));
		weightId = driver.findElement(By.id("weight"));
		costId = driver.findElement(By.id("cost"));
		dateId = driver.findElement(By.id("date"));
		deliveryId = driver.findElement(By.id("delivery"));

		calculateId = driver.findElement(By.id("calcuate"));
		resultId = driver.findElement(By.id("result"));

		assertTrue(isElementPresent(By.tagName("h2")));
		assertTrue(isElementPresent(By.id("source")));
		assertTrue(isElementPresent(By.id("destination")));
		assertTrue(isElementPresent(By.id("weight")));
		assertTrue(isElementPresent(By.id("cost")));
		assertTrue(isElementPresent(By.id("date")));
		assertTrue(isElementPresent(By.id("delivery")));
		assertTrue(isElementPresent(By.id("calculate")));
		assertTrue(isElementPresent(By.id("result")));

		sourceId.clear();
		sourceId.sendKeys("40,West cart road,Coimbatore");
		destinationId.clear();
		destinationId.sendKeys("40,West cart,Coimbatore");
		weightId.clear();
		weightId.sendKeys("40");
		driver.findElement(By.id("cost")).clear();
		driver.findElement(By.id("cost")).sendKeys("7");
		driver.findElement(By.id("date")).sendKeys("22/02/2017");
		driver.findElement(By.id("calculate")).click();
		String output = driver.findElement(By.id("result")).getText();
		System.out.println(output);
	}

	@After
	public void tearDown() throws Exception {

		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
